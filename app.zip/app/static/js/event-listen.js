    document.getElementById('submitBtn').addEventListener('click', sayWelcome);

    function sayWelcome() {
         var username = document.forms[0].username.value;
         var password = document.forms[0].pwd.value;
         if (username == '') {alert('username cannot be blank!')};
         if (password == '') {alert('password cannot be blank!')};
         if (username !== '' && password !== '') {
            alert("Welcome Back " + username + "! ");
            var answer = "Welcome Back " + username + "! ";
            document.getElementById('answer').innerHTML = answer;
         }
     } 

    document.getElementById('submitBtn').addEventListener('click', sayHello);

    function sayHello() {
         var username = document.forms[0].username.value;
         var password = document.forms[0].pwd.value;
         if (username == '') {alert('username cannot be blank!')};
         if (password == '') {alert('password cannot be blank!')};
         if (username !== '' && password !== '') {
            alert("Hello " + username + "! Welcome Abroad ");
            var answer = "Hello " + username + "! Welcome Abroad ";
            document.getElementById('answer').innerHTML = answer;
         }
     } 